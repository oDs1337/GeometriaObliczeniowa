import { Routes } from '@angular/router';
import { LineIntersectionComponent } from "./line-intersection/line-intersection.component";

export const routes: Routes = [
  {
    path: '',
    component: LineIntersectionComponent
  }
];
